#include "aether/aether.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

static std::string read_file(const std::string& path) {
  std::ifstream f(path);
  if (!f) throw std::runtime_error("cannot open file: " + path);
  std::ostringstream ss;
  ss << f.rdbuf();
  return ss.str();
}

static void usage() {
  std::cerr <<
    "aetherc — standalone AETHER compiler (v7+ bootstrap)\n"
    "Usage:\n"
    "  aetherc check   <file.ae>\n"
    "  aetherc run     <file.ae> <function> [args...]\n"
    "  aetherc fmt     <file.ae>\n"
    "  aetherc wat     <file.ae>\n"
    "  aetherc asm     <file.ae>\n"
    "  aetherc version\n";
}

int main(int argc, char** argv) {
  try {
    if (argc < 2) { usage(); return 2; }
    std::string cmd = argv[1];

    if (cmd == "version") {
      std::cout << "aetherc 7.1.0-standalone\n";
      return 0;
    }

    if (argc < 3) { usage(); return 2; }
    std::string src = read_file(argv[2]);
    auto tokens = aether::lex(src);
    auto prog   = aether::parse(tokens);

    if (cmd == "check") {
      std::cout << "OK  functions=" << prog.functions.size() << "\n";
      return 0;
    }
    if (cmd == "fmt") {
      std::cout << aether::format_program(prog);
      return 0;
    }
    if (cmd == "wat") {
      std::cout << aether::emit_wat(prog);
      return 0;
    }
    if (cmd == "asm") {
      std::cout << aether::emit_x86_64(prog);
      return 0;
    }
    if (cmd == "run") {
      if (argc < 4) {
        std::cerr << "run requires a function name\n";
        return 2;
      }
      std::vector<aether::Value> args;
      for (int i = 4; i < argc; ++i) {
        args.push_back(aether::Value::integer(std::stoll(argv[i])));
      }
      aether::VM vm(prog);
      aether::Value v = vm.call(argv[3], args);
      if (v.kind == aether::Value::Kind::Bool)
        std::cout << (v.b ? "true" : "false") << "\n";
      else if (v.kind == aether::Value::Kind::String)
        std::cout << v.s << "\n";
      else if (v.kind == aether::Value::Kind::Float)
        std::cout << v.f << "\n";
      else
        std::cout << v.i << "\n";
      return 0;
    }

    usage();
    return 2;
  } catch (const aether::Error& e) {
    std::cerr << "AETHER error:" << e.line << ":" << e.col << ": " << e.what() << "\n";
    return 1;
  } catch (const std::exception& e) {
    std::cerr << "AETHER error: " << e.what() << "\n";
    return 1;
  }
}
