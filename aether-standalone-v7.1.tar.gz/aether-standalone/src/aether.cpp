#include "aether/aether.hpp"
#include <algorithm>
#include <cctype>
#include <sstream>

namespace aether {

// ============================================================================
// Lexer
// ============================================================================
static Token make_tok(TokenKind k, std::string t, std::size_t l, std::size_t c) {
  return {k, std::move(t), l, c};
}

std::vector<Token> lex(std::string_view s) {
  std::vector<Token> out;
  std::size_t i = 0, line = 1, col = 1;

  auto add = [&](TokenKind k, std::size_t sl, std::size_t sc, std::string t) {
    out.push_back(make_tok(k, std::move(t), sl, sc));
  };

  while (i < s.size()) {
    char ch = s[i];

    if (ch == ' ' || ch == '\t' || ch == '\r') { ++i; ++col; continue; }
    if (ch == '\n') { add(TokenKind::Newline, line, col, "\\n"); ++i; ++line; col = 1; continue; }
    if (ch == '#') { while (i < s.size() && s[i] != '\n') { ++i; ++col; } continue; }

    std::size_t sl = line, sc = col;

    // identifier / keyword
    if (std::isalpha(static_cast<unsigned char>(ch)) || ch == '_' || ch == '$') {
      std::size_t st = i;
      while (i < s.size() && (std::isalnum(static_cast<unsigned char>(s[i])) || s[i] == '_' || s[i] == '$')) {
        ++i; ++col;
      }
      std::string w(s.substr(st, i - st));
      TokenKind k = TokenKind::Identifier;
      if      (w == "let")    k = TokenKind::Let;
      else if (w == "mut")    k = TokenKind::Mut;
      else if (w == "const")  k = TokenKind::Const;
      else if (w == "fn")     k = TokenKind::Fn;
      else if (w == "return") k = TokenKind::Return;
      else if (w == "if")     k = TokenKind::If;
      else if (w == "else")   k = TokenKind::Else;
      else if (w == "while")  k = TokenKind::While;
      else if (w == "true")   k = TokenKind::True;
      else if (w == "false")  k = TokenKind::False;
      add(k, sl, sc, std::move(w));
      continue;
    }

    // number
    if (std::isdigit(static_cast<unsigned char>(ch))) {
      std::size_t st = i;
      bool dot = false;
      while (i < s.size() && (std::isdigit(static_cast<unsigned char>(s[i])) || (s[i] == '.' && !dot))) {
        if (s[i] == '.') dot = true;
        ++i; ++col;
      }
      add(TokenKind::Number, sl, sc, std::string(s.substr(st, i - st)));
      continue;
    }

    // string
    if (ch == '"' || ch == '\'') {
      char q = ch; ++i; ++col;
      std::string v;
      while (i < s.size() && s[i] != q) {
        if (s[i] == '\\' && i + 1 < s.size()) { v += s[i + 1]; i += 2; col += 2; }
        else { v += s[i++]; ++col; }
      }
      if (i >= s.size()) throw Error("unterminated string", sl, sc);
      ++i; ++col;
      add(TokenKind::String, sl, sc, std::move(v));
      continue;
    }

    auto one = [&](TokenKind k) { add(k, sl, sc, std::string(1, ch)); ++i; ++col; };

    if (ch == '(') { one(TokenKind::LParen); continue; }
    if (ch == ')') { one(TokenKind::RParen); continue; }
    if (ch == '{') { one(TokenKind::LBrace); continue; }
    if (ch == '}') { one(TokenKind::RBrace); continue; }
    if (ch == ',') { one(TokenKind::Comma); continue; }
    if (ch == ':') { one(TokenKind::Colon); continue; }
    if (ch == ';') { one(TokenKind::Semicolon); continue; }
    if (ch == '+') { one(TokenKind::Plus); continue; }
    if (ch == '*') { one(TokenKind::Star); continue; }
    if (ch == '/') { one(TokenKind::Slash); continue; }
    if (ch == '%') { one(TokenKind::Percent); continue; }
    if (ch == '!') {
      if (i + 1 < s.size() && s[i + 1] == '=') { add(TokenKind::NotEq, sl, sc, "!="); i += 2; col += 2; }
      else one(TokenKind::Bang);
      continue;
    }
    if (ch == '=') {
      if (i + 1 < s.size() && s[i + 1] == '=') { add(TokenKind::EqEq, sl, sc, "=="); i += 2; col += 2; }
      else one(TokenKind::Eq);
      continue;
    }
    if (ch == '<') {
      if (i + 1 < s.size() && s[i + 1] == '=') { add(TokenKind::LtEq, sl, sc, "<="); i += 2; col += 2; }
      else one(TokenKind::Lt);
      continue;
    }
    if (ch == '>') {
      if (i + 1 < s.size() && s[i + 1] == '=') { add(TokenKind::GtEq, sl, sc, ">="); i += 2; col += 2; }
      else one(TokenKind::Gt);
      continue;
    }
    if (ch == '&' && i + 1 < s.size() && s[i + 1] == '&') {
      add(TokenKind::AmpAmp, sl, sc, "&&"); i += 2; col += 2; continue;
    }
    if (ch == '|' && i + 1 < s.size() && s[i + 1] == '|') {
      add(TokenKind::PipePipe, sl, sc, "||"); i += 2; col += 2; continue;
    }
    if (ch == '-') {
      if (i + 1 < s.size() && s[i + 1] == '>') { add(TokenKind::Arrow, sl, sc, "->"); i += 2; col += 2; }
      else one(TokenKind::Minus);
      continue;
    }

    throw Error(std::string("unexpected character: ") + ch, sl, sc);
  }

  add(TokenKind::End, line, col, "");
  return out;
}

// ============================================================================
// Parser
// ============================================================================
class Parser {
public:
  explicit Parser(const std::vector<Token>& toks) : t_(toks), i_(0) {}

  Program parse_program() {
    Program p;
    skip_newlines();
    while (!check(TokenKind::End)) {
      p.functions.push_back(parse_function());
      skip_newlines();
    }
    return p;
  }

private:
  const std::vector<Token>& t_;
  std::size_t i_;

  const Token& peek() const { return t_[i_]; }
  const Token& prev() const { return t_[i_ - 1]; }
  bool check(TokenKind k) const { return peek().kind == k; }

  bool match(TokenKind k) {
    if (check(k)) { ++i_; return true; }
    return false;
  }

  Token expect(TokenKind k, const char* msg) {
    if (!check(k)) throw Error(msg, peek().line, peek().col);
    Token tok = peek();
    ++i_;
    return tok;
  }

  void skip_newlines() {
    while (match(TokenKind::Newline)) {}
  }

  // fn name(params) -> expr
  // fn name(params) { stmts }
  Function parse_function() {
    expect(TokenKind::Fn, "expected 'fn'");
    Token name = expect(TokenKind::Identifier, "expected function name");
    expect(TokenKind::LParen, "expected '('");

    Function fn;
    fn.name = name.text;
    fn.line = name.line;
    fn.col  = name.col;

    if (!check(TokenKind::RParen)) {
      do {
        Token p = expect(TokenKind::Identifier, "expected parameter name");
        fn.params.push_back(p.text);
      } while (match(TokenKind::Comma));
    }
    expect(TokenKind::RParen, "expected ')'");

    if (match(TokenKind::Arrow)) {
      fn.is_expr_body = true;
      fn.expr_body = parse_expr();
    } else if (match(TokenKind::LBrace)) {
      fn.is_expr_body = false;
      skip_newlines();
      while (!check(TokenKind::RBrace) && !check(TokenKind::End)) {
        fn.body.push_back(parse_stmt());
        skip_newlines();
      }
      expect(TokenKind::RBrace, "expected '}'");
    } else {
      throw Error("expected '->' or '{'", peek().line, peek().col);
    }
    return fn;
  }

  std::unique_ptr<Stmt> parse_stmt() {
    auto s = std::make_unique<Stmt>();
    s->line = peek().line;
    s->col  = peek().col;

    if (match(TokenKind::Let) || match(TokenKind::Mut) || match(TokenKind::Const)) {
      s->kind = Stmt::Kind::Let;
      Token n = expect(TokenKind::Identifier, "expected variable name");
      s->name = n.text;
      expect(TokenKind::Eq, "expected '='");
      s->expr = parse_expr();
      match(TokenKind::Semicolon);
      return s;
    }
    if (match(TokenKind::Return)) {
      s->kind = Stmt::Kind::Return;
      if (!check(TokenKind::Newline) && !check(TokenKind::RBrace) && !check(TokenKind::Semicolon)) {
        s->expr = parse_expr();
      }
      match(TokenKind::Semicolon);
      return s;
    }
    if (match(TokenKind::While)) {
      s->kind = Stmt::Kind::While;
      s->cond = parse_expr();
      expect(TokenKind::LBrace, "expected '{'");
      skip_newlines();
      while (!check(TokenKind::RBrace) && !check(TokenKind::End)) {
        s->body.push_back(parse_stmt());
        skip_newlines();
      }
      expect(TokenKind::RBrace, "expected '}'");
      return s;
    }

    // expression statement
    s->kind = Stmt::Kind::Expr;
    s->expr = parse_expr();
    match(TokenKind::Semicolon);
    return s;
  }

  std::unique_ptr<Expr> parse_expr() { return parse_or(); }

  std::unique_ptr<Expr> parse_or() {
    auto e = parse_and();
    while (match(TokenKind::PipePipe)) {
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Binary;
      n->value = "||";
      n->lhs = std::move(e);
      n->rhs = parse_and();
      n->line = n->lhs->line; n->col = n->lhs->col;
      e = std::move(n);
    }
    return e;
  }

  std::unique_ptr<Expr> parse_and() {
    auto e = parse_equality();
    while (match(TokenKind::AmpAmp)) {
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Binary;
      n->value = "&&";
      n->lhs = std::move(e);
      n->rhs = parse_equality();
      n->line = n->lhs->line; n->col = n->lhs->col;
      e = std::move(n);
    }
    return e;
  }

  std::unique_ptr<Expr> parse_equality() {
    auto e = parse_comparison();
    while (match(TokenKind::EqEq) || match(TokenKind::NotEq)) {
      std::string op = prev().text;
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Binary;
      n->value = op;
      n->lhs = std::move(e);
      n->rhs = parse_comparison();
      n->line = n->lhs->line; n->col = n->lhs->col;
      e = std::move(n);
    }
    return e;
  }

  std::unique_ptr<Expr> parse_comparison() {
    auto e = parse_term();
    while (match(TokenKind::Lt) || match(TokenKind::LtEq) ||
           match(TokenKind::Gt) || match(TokenKind::GtEq)) {
      std::string op = prev().text;
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Binary;
      n->value = op;
      n->lhs = std::move(e);
      n->rhs = parse_term();
      n->line = n->lhs->line; n->col = n->lhs->col;
      e = std::move(n);
    }
    return e;
  }

  std::unique_ptr<Expr> parse_term() {
    auto e = parse_factor();
    while (match(TokenKind::Plus) || match(TokenKind::Minus)) {
      std::string op = prev().text;
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Binary;
      n->value = op;
      n->lhs = std::move(e);
      n->rhs = parse_factor();
      n->line = n->lhs->line; n->col = n->lhs->col;
      e = std::move(n);
    }
    return e;
  }

  std::unique_ptr<Expr> parse_factor() {
    auto e = parse_unary();
    while (match(TokenKind::Star) || match(TokenKind::Slash) || match(TokenKind::Percent)) {
      std::string op = prev().text;
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Binary;
      n->value = op;
      n->lhs = std::move(e);
      n->rhs = parse_unary();
      n->line = n->lhs->line; n->col = n->lhs->col;
      e = std::move(n);
    }
    return e;
  }

  std::unique_ptr<Expr> parse_unary() {
    if (match(TokenKind::Minus) || match(TokenKind::Bang)) {
      std::string op = prev().text;
      auto n = std::make_unique<Expr>();
      n->kind = Expr::Kind::Unary;
      n->value = op;
      n->rhs = parse_unary();
      n->line = prev().line; n->col = prev().col;
      return n;
    }
    return parse_primary();
  }

  std::unique_ptr<Expr> parse_primary() {
    if (match(TokenKind::Number)) {
      auto e = std::make_unique<Expr>();
      e->kind = Expr::Kind::Number;
      e->value = prev().text;
      e->line = prev().line; e->col = prev().col;
      return e;
    }
    if (match(TokenKind::String)) {
      auto e = std::make_unique<Expr>();
      e->kind = Expr::Kind::String;
      e->value = prev().text;
      e->line = prev().line; e->col = prev().col;
      return e;
    }
    if (match(TokenKind::True) || match(TokenKind::False)) {
      auto e = std::make_unique<Expr>();
      e->kind = Expr::Kind::Bool;
      e->value = prev().text;
      e->line = prev().line; e->col = prev().col;
      return e;
    }
    if (match(TokenKind::Identifier)) {
      std::string name = prev().text;
      std::size_t l = prev().line, c = prev().col;
      if (match(TokenKind::LParen)) {
        auto e = std::make_unique<Expr>();
        e->kind = Expr::Kind::Call;
        e->value = name;
        e->line = l; e->col = c;
        if (!check(TokenKind::RParen)) {
          do {
            e->args.push_back(parse_expr());
          } while (match(TokenKind::Comma));
        }
        expect(TokenKind::RParen, "expected ')'");
        return e;
      }
      auto e = std::make_unique<Expr>();
      e->kind = Expr::Kind::Name;
      e->value = name;
      e->line = l; e->col = c;
      return e;
    }
    if (match(TokenKind::LParen)) {
      auto e = parse_expr();
      expect(TokenKind::RParen, "expected ')'");
      return e;
    }
    if (match(TokenKind::If)) {
      auto e = std::make_unique<Expr>();
      e->kind = Expr::Kind::If;
      e->line = prev().line; e->col = prev().col;
      e->cond = parse_expr();
      // then
      if (match(TokenKind::LBrace)) {
        // treat block as a call-like sequence — simplify: require single expr for now in expr position
        skip_newlines();
        e->then_branch = parse_expr();
        skip_newlines();
        expect(TokenKind::RBrace, "expected '}'");
      } else {
        e->then_branch = parse_expr();
      }
      if (match(TokenKind::Else)) {
        if (match(TokenKind::LBrace)) {
          skip_newlines();
          e->else_branch = parse_expr();
          skip_newlines();
          expect(TokenKind::RBrace, "expected '}'");
        } else {
          e->else_branch = parse_expr();
        }
      }
      return e;
    }
    throw Error("expected expression", peek().line, peek().col);
  }
};

Program parse(const std::vector<Token>& tokens) {
  Parser p(tokens);
  return p.parse_program();
}

// ============================================================================
// VM
// ============================================================================
VM::VM(const Program& p) : program_(p) {}

const Function* VM::find(std::string_view name) const {
  for (const auto& f : program_.functions)
    if (f.name == name) return &f;
  return nullptr;
}

Value VM::eval_expr(const Expr& e, std::unordered_map<std::string, Value>& env) const {
  switch (e.kind) {
    case Expr::Kind::Number: {
      if (e.value.find('.') != std::string::npos)
        return Value::floating(std::stod(e.value));
      return Value::integer(std::stoll(e.value));
    }
    case Expr::Kind::String:
      return Value::string(e.value);
    case Expr::Kind::Bool:
      return Value::boolean(e.value == "true");
    case Expr::Kind::Name: {
      auto it = env.find(e.value);
      if (it == env.end()) throw Error("undefined variable: " + e.value, e.line, e.col);
      return it->second;
    }
    case Expr::Kind::Unary: {
      Value r = eval_expr(*e.rhs, env);
      if (e.value == "-") {
        if (r.kind == Value::Kind::Int) return Value::integer(-r.i);
        if (r.kind == Value::Kind::Float) return Value::floating(-r.f);
      }
      if (e.value == "!") {
        if (r.kind == Value::Kind::Bool) return Value::boolean(!r.b);
        if (r.kind == Value::Kind::Int) return Value::boolean(r.i == 0);
      }
      throw Error("invalid unary operand", e.line, e.col);
    }
    case Expr::Kind::Binary: {
      // short-circuit
      if (e.value == "&&") {
        Value l = eval_expr(*e.lhs, env);
        bool lb = (l.kind == Value::Kind::Bool) ? l.b : (l.i != 0);
        if (!lb) return Value::boolean(false);
        Value r = eval_expr(*e.rhs, env);
        bool rb = (r.kind == Value::Kind::Bool) ? r.b : (r.i != 0);
        return Value::boolean(rb);
      }
      if (e.value == "||") {
        Value l = eval_expr(*e.lhs, env);
        bool lb = (l.kind == Value::Kind::Bool) ? l.b : (l.i != 0);
        if (lb) return Value::boolean(true);
        Value r = eval_expr(*e.rhs, env);
        bool rb = (r.kind == Value::Kind::Bool) ? r.b : (r.i != 0);
        return Value::boolean(rb);
      }

      Value l = eval_expr(*e.lhs, env);
      Value r = eval_expr(*e.rhs, env);

      auto as_int = [](const Value& v) -> std::int64_t {
        if (v.kind == Value::Kind::Int) return v.i;
        if (v.kind == Value::Kind::Bool) return v.b ? 1 : 0;
        throw Error("expected integer", 0, 0);
      };

      if (e.value == "+") return Value::integer(as_int(l) + as_int(r));
      if (e.value == "-") return Value::integer(as_int(l) - as_int(r));
      if (e.value == "*") return Value::integer(as_int(l) * as_int(r));
      if (e.value == "/") {
        auto d = as_int(r);
        if (d == 0) throw Error("division by zero", e.line, e.col);
        return Value::integer(as_int(l) / d);
      }
      if (e.value == "%") {
        auto d = as_int(r);
        if (d == 0) throw Error("modulo by zero", e.line, e.col);
        return Value::integer(as_int(l) % d);
      }
      if (e.value == "==") return Value::boolean(as_int(l) == as_int(r));
      if (e.value == "!=") return Value::boolean(as_int(l) != as_int(r));
      if (e.value == "<")  return Value::boolean(as_int(l) <  as_int(r));
      if (e.value == "<=") return Value::boolean(as_int(l) <= as_int(r));
      if (e.value == ">")  return Value::boolean(as_int(l) >  as_int(r));
      if (e.value == ">=") return Value::boolean(as_int(l) >= as_int(r));
      throw Error("unknown operator: " + e.value, e.line, e.col);
    }
    case Expr::Kind::Call: {
      const Function* fn = find(e.value);
      if (!fn) throw Error("undefined function: " + e.value, e.line, e.col);
      if (e.args.size() != fn->params.size())
        throw Error("argument count mismatch for " + e.value, e.line, e.col);

      std::vector<Value> args;
      for (const auto& a : e.args) args.push_back(eval_expr(*a, env));

      std::unordered_map<std::string, Value> child;
      for (std::size_t i = 0; i < fn->params.size(); ++i)
        child[fn->params[i]] = args[i];

      return exec_body(*fn, child);
    }
    case Expr::Kind::If: {
      Value c = eval_expr(*e.cond, env);
      bool truth = (c.kind == Value::Kind::Bool) ? c.b : (c.i != 0);
      if (truth) return eval_expr(*e.then_branch, env);
      if (e.else_branch) return eval_expr(*e.else_branch, env);
      return Value::unit();
    }
    default:
      throw Error("unsupported expression kind", e.line, e.col);
  }
}

Value VM::exec_stmt(const Stmt& s, std::unordered_map<std::string, Value>& env) const {
  switch (s.kind) {
    case Stmt::Kind::Let:
    case Stmt::Kind::Mut:
      env[s.name] = eval_expr(*s.expr, env);
      return Value::unit();
    case Stmt::Kind::Return:
      if (s.expr) return eval_expr(*s.expr, env);
      return Value::unit();
    case Stmt::Kind::Expr:
      return eval_expr(*s.expr, env);
    case Stmt::Kind::While: {
      while (true) {
        Value c = eval_expr(*s.cond, env);
        bool truth = (c.kind == Value::Kind::Bool) ? c.b : (c.i != 0);
        if (!truth) break;
        for (const auto& st : s.body) {
          Value r = exec_stmt(*st, env);
          // simplistic: if a return happened we would need a flag; keep simple for now
          (void)r;
        }
      }
      return Value::unit();
    }
    default:
      return Value::unit();
  }
}

Value VM::exec_body(const Function& fn, std::unordered_map<std::string, Value>& env) const {
  if (fn.is_expr_body) {
    return eval_expr(*fn.expr_body, env);
  }
  Value last = Value::unit();
  for (const auto& st : fn.body) {
    if (st->kind == Stmt::Kind::Return) {
      return st->expr ? eval_expr(*st->expr, env) : Value::unit();
    }
    last = exec_stmt(*st, env);
  }
  return last;
}

Value VM::call(std::string_view name, const std::vector<Value>& args) const {
  const Function* fn = find(name);
  if (!fn) throw Error("undefined function: " + std::string(name), 1, 1);
  if (args.size() != fn->params.size())
    throw Error("argument count mismatch", 1, 1);

  std::unordered_map<std::string, Value> env;
  for (std::size_t i = 0; i < fn->params.size(); ++i)
    env[fn->params[i]] = args[i];

  return exec_body(*fn, env);
}

// ============================================================================
// x86-64 backend (System V AMD64)
// Supports: integers, params (≤6), locals, binary ops, comparisons,
//           unary ops, function calls, simple if, recursion
// ============================================================================
struct X86Context {
  const Program* prog;
  std::ostringstream o;
  int label = 0;
  std::unordered_map<std::string, int> local_slot; // name -> stack slot
  int stack_slots = 0;
  const Function* current = nullptr;

  std::string fresh(const std::string& prefix) {
    return prefix + std::to_string(label++);
  }
};

static const char* arg_reg(int idx) {
  static const char* regs[] = {"%rdi", "%rsi", "%rdx", "%rcx", "%r8", "%r9"};
  if (idx < 0 || idx >= 6) return nullptr;
  return regs[idx];
}

static void x86_expr(X86Context& ctx, const Expr& e);

static void x86_expr(X86Context& ctx, const Expr& e) {
  switch (e.kind) {
    case Expr::Kind::Number:
      ctx.o << "  mov $" << e.value << ", %rax\n";
      return;

    case Expr::Kind::Bool:
      ctx.o << "  mov $" << (e.value == "true" ? 1 : 0) << ", %rax\n";
      return;

    case Expr::Kind::Name: {
      // parameter?
      if (ctx.current) {
        auto it = std::find(ctx.current->params.begin(), ctx.current->params.end(), e.value);
        if (it != ctx.current->params.end()) {
          int idx = static_cast<int>(std::distance(ctx.current->params.begin(), it));
          const char* r = arg_reg(idx);
          if (!r) throw Error("too many parameters for native backend", e.line, e.col);
          ctx.o << "  mov " << r << ", %rax\n";
          return;
        }
      }
      // local?
      auto lit = ctx.local_slot.find(e.value);
      if (lit != ctx.local_slot.end()) {
        ctx.o << "  mov -" << (lit->second * 8) << "(%rbp), %rax\n";
        return;
      }
      throw Error("native backend: unknown name '" + e.value + "'", e.line, e.col);
    }

    case Expr::Kind::Unary: {
      x86_expr(ctx, *e.rhs);
      if (e.value == "-") {
        ctx.o << "  neg %rax\n";
      } else if (e.value == "!") {
        ctx.o << "  test %rax, %rax\n";
        ctx.o << "  sete %al\n";
        ctx.o << "  movzbq %al, %rax\n";
      }
      return;
    }

    case Expr::Kind::Binary: {
      // evaluate lhs, push; evaluate rhs into rcx; op
      x86_expr(ctx, *e.lhs);
      ctx.o << "  push %rax\n";
      x86_expr(ctx, *e.rhs);
      ctx.o << "  mov %rax, %rcx\n";
      ctx.o << "  pop %rax\n";

      if (e.value == "+") { ctx.o << "  add %rcx, %rax\n"; return; }
      if (e.value == "-") { ctx.o << "  sub %rcx, %rax\n"; return; }
      if (e.value == "*") { ctx.o << "  imul %rcx, %rax\n"; return; }
      if (e.value == "/") {
        ctx.o << "  cqo\n";
        ctx.o << "  idiv %rcx\n";
        return;
      }
      if (e.value == "%") {
        ctx.o << "  cqo\n";
        ctx.o << "  idiv %rcx\n";
        ctx.o << "  mov %rdx, %rax\n";
        return;
      }
      // comparisons
      ctx.o << "  cmp %rcx, %rax\n";
      if      (e.value == "==") ctx.o << "  sete %al\n";
      else if (e.value == "!=") ctx.o << "  setne %al\n";
      else if (e.value == "<")  ctx.o << "  setl %al\n";
      else if (e.value == "<=") ctx.o << "  setle %al\n";
      else if (e.value == ">")  ctx.o << "  setg %al\n";
      else if (e.value == ">=") ctx.o << "  setge %al\n";
      else throw Error("native backend unsupported op: " + e.value, e.line, e.col);
      ctx.o << "  movzbq %al, %rax\n";
      return;
    }

    case Expr::Kind::Call: {
      // evaluate arguments right-to-left, push, then pop into regs
      int n = static_cast<int>(e.args.size());
      if (n > 6) throw Error("native backend supports max 6 arguments", e.line, e.col);

      for (int i = n - 1; i >= 0; --i) {
        x86_expr(ctx, *e.args[i]);
        ctx.o << "  push %rax\n";
      }
      for (int i = 0; i < n; ++i) {
        ctx.o << "  pop " << arg_reg(i) << "\n";
      }
      // align stack? keep simple — assume caller handles for now
      ctx.o << "  call " << e.value << "\n";
      return;
    }

    case Expr::Kind::If: {
      std::string else_l = ctx.fresh(".Lelse_");
      std::string end_l  = ctx.fresh(".Lend_");
      x86_expr(ctx, *e.cond);
      ctx.o << "  test %rax, %rax\n";
      ctx.o << "  je " << else_l << "\n";
      x86_expr(ctx, *e.then_branch);
      ctx.o << "  jmp " << end_l << "\n";
      ctx.o << else_l << ":\n";
      if (e.else_branch) x86_expr(ctx, *e.else_branch);
      else ctx.o << "  mov $0, %rax\n";
      ctx.o << end_l << ":\n";
      return;
    }

    default:
      throw Error("native backend cannot lower this expression yet", e.line, e.col);
  }
}

static void emit_function(X86Context& ctx, const Function& fn) {
  ctx.current = &fn;
  ctx.local_slot.clear();
  ctx.stack_slots = 0;

  ctx.o << ".globl " << fn.name << "\n";
  ctx.o << ".type " << fn.name << ", @function\n";
  ctx.o << fn.name << ":\n";
  ctx.o << "  push %rbp\n";
  ctx.o << "  mov %rsp, %rbp\n";

  // allocate space for locals later if needed (keep 0 for pure expr body)
  if (fn.is_expr_body) {
    x86_expr(ctx, *fn.expr_body);
  } else {
    // very simple statement support: only return expr and let
    for (const auto& st : fn.body) {
      if (st->kind == Stmt::Kind::Let || st->kind == Stmt::Kind::Mut) {
        int slot = ++ctx.stack_slots;
        ctx.local_slot[st->name] = slot;
        ctx.o << "  sub $8, %rsp\n";
        x86_expr(ctx, *st->expr);
        ctx.o << "  mov %rax, -" << (slot * 8) << "(%rbp)\n";
      } else if (st->kind == Stmt::Kind::Return) {
        if (st->expr) x86_expr(ctx, *st->expr);
        else ctx.o << "  mov $0, %rax\n";
        break;
      } else if (st->kind == Stmt::Kind::Expr) {
        x86_expr(ctx, *st->expr);
      }
    }
  }

  ctx.o << "  mov %rbp, %rsp\n";
  ctx.o << "  pop %rbp\n";
  ctx.o << "  ret\n\n";
  ctx.current = nullptr;
}

std::string emit_x86_64(const Program& p) {
  X86Context ctx;
  ctx.prog = &p;
  ctx.o << ".text\n";
  ctx.o << ".intel_syntax noprefix\n";  // we actually emit AT&T; remove if needed
  // Force AT&T (GNU as default)
  ctx.o.str("");
  ctx.o << ".text\n";

  for (const auto& fn : p.functions) {
    emit_function(ctx, fn);
  }
  return ctx.o.str();
}

// ============================================================================
// WAT backend (subset)
// ============================================================================
static void wat_expr(std::ostringstream& o, const Expr& e) {
  switch (e.kind) {
    case Expr::Kind::Number:
      o << "i64.const " << e.value;
      return;
    case Expr::Kind::Bool:
      o << "i64.const " << (e.value == "true" ? 1 : 0);
      return;
    case Expr::Kind::Name:
      o << "local.get $" << e.value;
      return;
    case Expr::Kind::Unary:
      wat_expr(o, *e.rhs);
      if (e.value == "-") o << "\n    i64.const -1\n    i64.mul";
      return;
    case Expr::Kind::Binary: {
      wat_expr(o, *e.lhs);
      o << "\n    ";
      wat_expr(o, *e.rhs);
      o << "\n    ";
      if      (e.value == "+")  o << "i64.add";
      else if (e.value == "-")  o << "i64.sub";
      else if (e.value == "*")  o << "i64.mul";
      else if (e.value == "/")  o << "i64.div_s";
      else if (e.value == "%")  o << "i64.rem_s";
      else if (e.value == "==") o << "i64.eq";
      else if (e.value == "!=") o << "i64.ne";
      else if (e.value == "<")  o << "i64.lt_s";
      else if (e.value == "<=") o << "i64.le_s";
      else if (e.value == ">")  o << "i64.gt_s";
      else if (e.value == ">=") o << "i64.ge_s";
      return;
    }
    case Expr::Kind::Call: {
      for (const auto& a : e.args) {
        wat_expr(o, *a);
        o << "\n    ";
      }
      o << "call $" << e.value;
      return;
    }
    default:
      o << "i64.const 0";
  }
}

std::string emit_wat(const Program& p) {
  std::ostringstream o;
  o << "(module\n";
  for (const auto& f : p.functions) {
    o << "  (func $" << f.name;
    for (const auto& param : f.params) o << " (param $" << param << " i64)";
    o << " (result i64)\n    ";
    if (f.is_expr_body) wat_expr(o, *f.expr_body);
    else o << "i64.const 0";
    o << "\n  )\n";
  }
  // export all
  for (const auto& f : p.functions) {
    o << "  (export \"" << f.name << "\" (func $" << f.name << "))\n";
  }
  o << ")\n";
  return o.str();
}

// ============================================================================
// Formatter
// ============================================================================
static void fmt_expr(const Expr& e, std::ostringstream& o) {
  switch (e.kind) {
    case Expr::Kind::Number:
    case Expr::Kind::String:
    case Expr::Kind::Name:
    case Expr::Kind::Bool:
      o << e.value;
      return;
    case Expr::Kind::Unary:
      o << e.value;
      fmt_expr(*e.rhs, o);
      return;
    case Expr::Kind::Binary:
      o << "(";
      fmt_expr(*e.lhs, o);
      o << " " << e.value << " ";
      fmt_expr(*e.rhs, o);
      o << ")";
      return;
    case Expr::Kind::Call:
      o << e.value << "(";
      for (std::size_t i = 0; i < e.args.size(); ++i) {
        if (i) o << ", ";
        fmt_expr(*e.args[i], o);
      }
      o << ")";
      return;
    case Expr::Kind::If:
      o << "if ";
      fmt_expr(*e.cond, o);
      o << " ";
      fmt_expr(*e.then_branch, o);
      if (e.else_branch) {
        o << " else ";
        fmt_expr(*e.else_branch, o);
      }
      return;
    default:
      o << "?";
  }
}

std::string format_program(const Program& p) {
  std::ostringstream o;
  for (const auto& f : p.functions) {
    o << "fn " << f.name << "(";
    for (std::size_t i = 0; i < f.params.size(); ++i) {
      if (i) o << ", ";
      o << f.params[i];
    }
    o << ")";
    if (f.is_expr_body) {
      o << " -> ";
      fmt_expr(*f.expr_body, o);
      o << "\n";
    } else {
      o << " { ... }\n";
    }
  }
  return o.str();
}

} // namespace aether
