# AETHER Language — Standalone Bootstrap v7.1

**Host-agnostic. Self-contained. No browser required.**

AETHER is an experimental programming language. This repository contains a clean, working standalone bootstrap implementation.

## What works right now

| Feature | Status |
|---------|--------|
| Standalone CLI compiler | Working (`aetherc`) |
| Lexer + Parser | Working |
| Tree-walking VM / Interpreter | Working |
| x86-64 native backend | Working (calls, recursion, if) |
| WebAssembly Text (WAT) backend | Working (basic subset) |
| Formatter | Working |
| Self-hosting proof (AETHER-in-AETHER) | Working (16/16 tests passed) |
| Browser / HTML dependency | **None** |

## Build

Requirements: CMake 3.16+, C++17 compiler (GCC or Clang)

```bash
cmake -S . -B build
cmake --build build --parallel
```

## Usage

```bash
./build/aetherc version
./build/aetherc check tests/smoke.ae
./build/aetherc run   tests/smoke.ae fact 5
./build/aetherc run   tests/smoke.ae fib 10
./build/aetherc asm   tests/smoke.ae
./build/aetherc wat   tests/smoke.ae
./build/aetherc fmt   tests/smoke.ae

# Self-hosting proof (pure AETHER)
./build/aetherc run selfhost/meta_eval.ae main
# Expected output: 0
```

## Native backend smoke test

```bash
./build/aetherc asm tests/smoke.ae > /tmp/aether.s
as /tmp/aether.s -o /tmp/aether.o
cc tests/native_smoke.c /tmp/aether.o -o /tmp/aether-native
./tmp/aether-native
# Expected: native backend: PASS
```

## Language subset (honest)

**Supported today:**
- Functions with expression bodies: `fn name(params) -> expr`
- Integers and booleans
- Arithmetic: `+ - * / %`
- Comparisons: `== != < <= > >=`
- Unary `-`
- `if` expressions
- Function calls and recursion
- Simple `let` / `return` in statement bodies

**Not yet supported:**
- Full historical AETHER surface (tensors, agents, HyperFS, etc.)
- Complete self-hosting (compiler written in AETHER)
- Floating-point native lowering
- Strings in native backend
- Closures
- Large standard library

## Project layout

```
aether-standalone/
├── CMakeLists.txt
├── README.md
├── LICENSE
├── VERSION
├── .gitignore
├── include/aether/aether.hpp
├── src/
│   ├── aether.cpp
│   └── main.cpp
├── tests/
│   ├── smoke.ae
│   └── native_smoke.c
└── selfhost/
    ├── README.md
    └── meta_eval.ae
```

## Design principles

1. **Standalone first** — must run without a browser or foreign runtime.
2. **Honest scope** — only claim what currently executes and passes tests.
3. **Bootstrap path** — C++ is temporary. Goal is AETHER implementing AETHER.
4. **Native capability** — real machine code, not only interpretation.

## Verification (clean build)

```
aetherc version                        → aetherc 7.1.0-standalone
aetherc run tests/smoke.ae fact 5      → 120
aetherc run selfhost/meta_eval.ae main → 0
native smoke                           → native backend: PASS
```

## License

MIT License — see LICENSE file.
