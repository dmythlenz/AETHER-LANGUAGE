#pragma once
#include <cstdint>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace aether {

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------
enum class TokenKind {
  End, Identifier, Number, String,
  Let, Mut, Const, Fn, Return, If, Else, While,
  True, False,
  LParen, RParen, LBrace, RBrace, Comma, Colon, Semicolon, Arrow,
  Plus, Minus, Star, Slash, Percent,
  Eq, EqEq, NotEq, Lt, LtEq, Gt, GtEq,
  Bang, AmpAmp, PipePipe,
  Newline
};

struct Token {
  TokenKind kind;
  std::string text;
  std::size_t line = 1;
  std::size_t col  = 1;
};

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------
class Error : public std::runtime_error {
public:
  std::size_t line, col;
  Error(std::string msg, std::size_t l, std::size_t c)
    : std::runtime_error(std::move(msg)), line(l), col(c) {}
};

// ---------------------------------------------------------------------------
// AST
// ---------------------------------------------------------------------------
struct Expr {
  enum class Kind {
    Number, String, Name, Bool,
    Binary, Unary, Call, If, Block
  } kind;

  std::string value;                          // number/string/name/op
  std::vector<std::unique_ptr<Expr>> args;    // call args or block stmts
  std::unique_ptr<Expr> lhs, rhs, cond;       // binary / unary / if
  std::unique_ptr<Expr> then_branch, else_branch;
  std::size_t line = 1, col = 1;
};

struct Stmt {
  enum class Kind { Expr, Let, Mut, Return, While, Block } kind;
  std::string name;
  std::unique_ptr<Expr> expr;
  std::unique_ptr<Expr> cond;
  std::vector<std::unique_ptr<Stmt>> body;
  std::size_t line = 1, col = 1;
};

struct Function {
  std::string name;
  std::vector<std::string> params;
  std::vector<std::unique_ptr<Stmt>> body;   // statement body
  std::unique_ptr<Expr> expr_body;           // or single expression body
  bool is_expr_body = false;
  std::size_t line = 1, col = 1;
};

struct Program {
  std::vector<Function> functions;
};

// ---------------------------------------------------------------------------
// Values (for VM)
// ---------------------------------------------------------------------------
struct Value {
  enum class Kind { Int, Float, String, Bool, Unit, Error } kind = Kind::Int;
  std::int64_t i = 0;
  double f = 0.0;
  std::string s;
  bool b = false;

  static Value integer(std::int64_t v) { Value x; x.kind = Kind::Int; x.i = v; return x; }
  static Value floating(double v)      { Value x; x.kind = Kind::Float; x.f = v; return x; }
  static Value boolean(bool v)         { Value x; x.kind = Kind::Bool; x.b = v; return x; }
  static Value string(std::string v)   { Value x; x.kind = Kind::String; x.s = std::move(v); return x; }
  static Value unit()                  { Value x; x.kind = Kind::Unit; return x; }
};

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
std::vector<Token> lex(std::string_view source);
Program parse(const std::vector<Token>& tokens);

class VM {
public:
  explicit VM(const Program& p);
  Value call(std::string_view name, const std::vector<Value>& args) const;
private:
  const Program& program_;
  const Function* find(std::string_view name) const;
  Value eval_expr(const Expr& e, std::unordered_map<std::string, Value>& env) const;
  Value exec_stmt(const Stmt& s, std::unordered_map<std::string, Value>& env) const;
  Value exec_body(const Function& fn, std::unordered_map<std::string, Value>& env) const;
};

std::string emit_x86_64(const Program& p);
std::string emit_wat(const Program& p);
std::string format_program(const Program& p);

} // namespace aether
