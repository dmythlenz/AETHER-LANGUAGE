# AETHER Self-Hosting Step 1

## Result

```
aetherc run selfhost/meta_eval.ae main
→ 0
```

**0 = all 16 self-hosting tests passed.**

This program is pure AETHER. It runs on the standalone `aetherc` compiler.
No HTML. No JavaScript. No Python.

## What this proves

AETHER can already express:

- Arithmetic and comparison
- Conditional logic (`if`)
- Recursion (`fact`, `fib`, `pow`, `gcd`)
- Higher-order style testing of its own evaluation helpers
- A complete self-test suite written in itself

## What this does *not* yet prove

- Full AST interpretation of arbitrary AETHER source
- A complete compiler written in AETHER
- Closed self-hosting (AETHER compiling AETHER with no C++ left)

Those are the next stages.

## How to run

```bash
cd aether-standalone
./build/aetherc run selfhost/meta_eval.ae main
```

Expected output: `0`
