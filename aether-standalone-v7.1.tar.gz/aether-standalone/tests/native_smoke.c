#include <stdio.h>

/* These symbols are produced by aetherc asm + assembler */
long add(long, long);
long square(long);
long compare(long, long);
long fact(long);
long max(long, long);

int main(void) {
  if (add(20, 22) != 42)      { puts("FAIL add"); return 1; }
  if (square(9) != 81)        { puts("FAIL square"); return 2; }
  if (compare(10, 7) != 1)    { puts("FAIL compare"); return 3; }
  if (fact(5) != 120)         { puts("FAIL fact"); return 4; }
  if (max(3, 9) != 9)         { puts("FAIL max"); return 5; }
  puts("native backend: PASS");
  return 0;
}
