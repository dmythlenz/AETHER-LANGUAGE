# Self-Hosting Proof

This directory contains the first self-hosting step for AETHER.

## meta_eval.ae

A pure AETHER program that implements evaluation helpers and recursive functions, then tests itself.

```bash
../build/aetherc run meta_eval.ae main
```

Expected result:

```
0
```

`0` means all 16 internal tests passed.

## What this proves

AETHER can already express and execute:

- Arithmetic and comparison
- Conditional logic
- Recursion (`fact`, `fib`, `pow`, `gcd`)
- Self-testing logic

## What this does not prove yet

- Full source-level interpreter written in AETHER
- Complete compiler written in AETHER
- Closed self-hosting loop

Those are future milestones.
